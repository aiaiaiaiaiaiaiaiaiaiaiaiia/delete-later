import HomePage from "./homePage";
import CartPage from "./cartPage";

export {HomePage, CartPage};