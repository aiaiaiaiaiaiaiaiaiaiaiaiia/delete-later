import React from 'react'

const CartPage = () => {
  return (
    <div>cartPage</div>
  )
}

export default CartPage;